#!/bin/bash

# Set Python interpreter (modify if using a virtual environment)
PYTHON_EXEC=python3

# Ensure the script is executed with a search query
if [ $# -eq 0 ]; then
    echo "Usage: $0 \"search_query\""
    exit 1
fi

# Define the search query from script arguments
SEARCH_QUERY="$1"

# Run the Lucene search script with the provided query
$PYTHON_EXEC -c "
import sys
from lucene_query import LuceneSearcher

try:
    searcher = LuceneSearcher()
    searcher.search(\"$SEARCH_QUERY\")
except Exception as e:
    print(f'Error: {str(e)}')
    sys.exit(1)
"
